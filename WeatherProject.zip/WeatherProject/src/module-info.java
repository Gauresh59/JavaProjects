module WeatherProject {
	requires java.json;
	requires org.apache.commons.io;
	requires apache.logging.log4j;
}